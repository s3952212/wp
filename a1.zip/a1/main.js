function navigate(url) {
    window.location.href = url;
}