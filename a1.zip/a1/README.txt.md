# Assessment 1
https://jupiter.csit.rmit.edu.au/~s3952212/wp/a1/

